## Test script ## 
# For all the things we want to test 
# import numpy as np 
# with open('turbine_32x32x8192.bin','rb') as f: 
#     init_data = np.fromfile(f,np.single)

#init_data = np.fromfile('turbine_32x32x8192.bin')
Nx = 32
Ny = 32
Nz = 8192
# # print(data)
# print(np.size(init_data))

# if (np.size(init_data) == Nx * Ny * Nz): 
#     data = np.reshape(init_data,(Nx,Ny,Nz))
#     print(data)
#     print(np.size(data))
# else: 
#     print('ERROR')


# import numpy as np 
# # a = np.array([[1,2,3,4],[5,6,7,8],[9,10,11,12]])
# # print(a) 
# # print(np.reshape(a,(3,1,4)))

# b = np.array([[1,2,3,4],[1,2,3,4]])
# print(b)
# print(np.sum(b,axis=0))

